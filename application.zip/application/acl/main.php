<?php

return [
	'all' => [
		'index',
	],
	'authorize' => [
		//
	],
	'guest' => [
		//
	],
	'admin' => [
		//
	], 
];