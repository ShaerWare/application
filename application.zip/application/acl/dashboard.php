<?php

return [
	'all' => [
		//
	],
	'authorize' => [
		'reg',
		'swift',
		'tariffs',
		'invest',
		'history',
		'referrals',
	],
	'guest' => [
		'confirm',
	],
	'admin' => [
		//
	],
	/*'agent' => [
		'reg',
		'swift',
	]*/
];