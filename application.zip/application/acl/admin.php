<?php

return [
	'all' => [
		'login',
	],
	'authorize' => [
		//
	],
	'guest' => [
		//
	],
	'admin' => [
		'agents',
		'zapros',
		'accounts',
		'withdraw',
		'tariffs',
		'history',
		'logout',
	],
];