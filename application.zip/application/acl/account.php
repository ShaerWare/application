<?php

return [
	'all' => [
		//
	],
	'authorize' => [
		'profile',
		'logout',
	],
	'guest' => [
		'register',
		'login',
		'recovery',
		'confirm',
		'reset',
	],
	'admin' => [
		//
	],
	/*'agent' => [
		'reg',
		'swift',
	]*/
];