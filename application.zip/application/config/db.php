<?php

return [
	'host' => 'localhost',
	'name' => 'localhost',
	'user' => 'root',
	'password' => '',
];
