<?php

namespace application\controllers;

use application\core\Controller;

class MainController extends Controller {

	public function indexAction() {
		$vars = [
			'tariffs' => $this->tariffs,
		];
		$this->view->render('Главная страница', $vars);
	}

	public function localeAction() {
		 
		if (isset($_POST['locale'])){
			$locale = $_POST['locale'];
		}
		else    {
			$locale = 'ru_RUx';
				}
		$_SESSION['locale'] = $locale;

		
		
		//$this->view->render('Главная страница');
	}


}